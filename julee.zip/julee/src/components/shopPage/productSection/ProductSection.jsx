import React from 'react'
import ProductBar from './ProductBar'
const ProductSection = () => {
  return (
    <article className="productSection">
    <ProductBar/>
</article>
  )
}

export default ProductSection