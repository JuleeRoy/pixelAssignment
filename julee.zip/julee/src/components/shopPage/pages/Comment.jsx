import React from 'react'

const Comment = () => {
  return (
    <div>Comment</div>
  )
}

export default Comment