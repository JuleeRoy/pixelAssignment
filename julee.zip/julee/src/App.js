import React from 'react'
import Home from './components/HomePage/home/Home'
import Shop from './components/shopPage/shop/Shop'
import { BrowserRouter,Route,Routes } from 'react-router-dom';
import Navbar from './components/HomePage/navbar/Navbar';

const App = () => {
  return (
    
    
      <Home/>
      
    
  )
}

export default App